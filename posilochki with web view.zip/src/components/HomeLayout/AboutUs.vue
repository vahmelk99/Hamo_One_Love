<template>
    <div class="app">
        <h2 class="text-center my-5"><b>О нас пишут</b></h2>
        <div class="d-flex justify-content-center flex-wrap px-4">
            <div>
                <img src="../../../img/page1/Mask Group 8.png" alt="meduza">
            </div>
            <div>
                <img src="../../../img/page1/Mask Group 7.png" alt="vc.ru">
            </div>
            <div>
                <img src="../../../img/page1/Mask Group 6.png" alt="Коммерсант.ru">
            </div>
            <div>
                <img src="../../../img/page1/Mask Group 5.png" alt="РБК">
            </div>
            <div>
                <img src="../../../img/page1/Mask Group 4.png" alt="RUSBASE">
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'AboutUs'
}
</script>

<style scoped>
h2{
    color: #f9b21f;
}
img{
    cursor: pointer;
    width: 180px;
    padding: 0 10px;
}
</style>
